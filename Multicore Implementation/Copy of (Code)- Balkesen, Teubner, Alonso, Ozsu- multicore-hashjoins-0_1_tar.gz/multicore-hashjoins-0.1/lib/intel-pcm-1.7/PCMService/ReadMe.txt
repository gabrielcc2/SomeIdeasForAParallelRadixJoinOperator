========================================================================
    APPLICATION : PMU Service Project Overview
========================================================================

Windows Service Wizard has created this PMU Service Application for you.  

This file contains a summary of what you will find in each of the files that
make up your PMU Service application.

PMU Service.vcproj
    This is the main project file for VC++ projects generated using a Windows Service Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations.

PMU ServiceWinService.cpp
    This is the main application source file.

AssemblyInfo.cpp
	Contains custom attributes for modifying assembly metadata.


/////////////////////////////////////////////////////////////////////////////
Other notes:

Windows Service Wizard uses "TODO:" to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////

To run your service:
	1. Build the project
	2. From the command line, run:
		PMU Service.exe -Install
