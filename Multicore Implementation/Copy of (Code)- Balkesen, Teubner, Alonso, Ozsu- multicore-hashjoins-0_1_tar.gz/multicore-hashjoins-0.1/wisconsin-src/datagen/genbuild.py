maxkeyval = 16*1024*1024;

for i in xrange(1, maxkeyval+1):
	print str(i) + '|' + str(i)
